﻿int num1 = int.Parse(Console.ReadLine());
int num2 = int.Parse(Console.ReadLine());

if(num1 < 100000 || num1 > 300000)
{
    Console.WriteLine("Invalid value for num1! Please type digit between 100000 and 300000!");
    return;
}

if (num2 < 100000 || num2 > 300000)
{
    Console.WriteLine("Invalid value for num2! Please type digit between 100000 and 300000!");
    return;
}

if(num1 > num2)
{
    Console.WriteLine("Num1 must be less than Num2!");
    return;
}

for(int i = num1; i<= num2; i++)////526453
{
    int sum1 = (i /100000) % 10;
    int sum2 = (i / 10000) % 10;
    int sum3 = (i / 1000) % 10;
    int sum4 = (i / 100) % 10;
    int sum5 = (i / 10) % 10;
    int sum6 = i % 10;

    if(sum1 + sum3 + sum5 == sum2 + sum4 + sum6)
    {
        Console.Write(i + " ");
    }
}