﻿int n = int.Parse(Console.ReadLine());
if(n < 1 || n > 600000)
{
    Console.WriteLine("Invalid value for n! Please type digit between 1 and 600000!");
    return;
}

for(int i = 1111; i <= 9999; i++)
{
    int num1 = (i / 1000);
    int num2 = (i / 100)%10;
    int num3 = (i / 10) %10;
    int num4 = i % 10;

    if(num2 == 0)
    {
        i += 100; 
    }
    if (num3 == 0)
    {
        i += 10;
    }
    if (num4 == 0)
    {
        i += 1;
    }

    num2 = (i / 100) % 10;
    num3 = (i / 10) % 10;
    num4 = i % 10;


    if (n % num1 == 0 && n % num2 == 0 && n % num3 == 0 && n % num4 == 0)
    {
        Console.Write(i + " ");
    }
}