﻿// See https://aka.ms/new-console-template for more information
int brGrades = 0;
int sumGrades = 0;
int brTasks = 0;
string memory = "memory";
bool end = false;

int brBadGrades = int.Parse(Console.ReadLine());
if (brBadGrades < 1 || brBadGrades > 5)
{
    Console.WriteLine("Invalid amount of bad grades! Please type digit between 1 and 5!");
}
int brBadGrades2 = 0;
string nameOfTask = "something";
int grade;
while (nameOfTask != "Enough")
{
    nameOfTask = Console.ReadLine();
    if(nameOfTask == "Enough")
    {
        end = true;
        break;
    }
    memory = nameOfTask;
    brTasks++;
    grade = int.Parse(Console.ReadLine());

    if (grade < 2 || grade > 6)
    {
        Console.WriteLine("Invalid amount of grade! Please type digit between 2 and 6!");
    }
    brGrades++;
    sumGrades = sumGrades + grade;
    if (grade <= 4)
    {
        brBadGrades2++;
    }

    if (brBadGrades2 == brBadGrades)
    {
        Console.WriteLine("Take a break, you have {0} bad grades!", brBadGrades2);
    }
}
if(end == true)
{
    double avg = sumGrades / brGrades;
    Console.WriteLine("Average grade: {0:f2}",avg);
    Console.WriteLine("Amount tasks: " + brTasks);
    Console.WriteLine("Last task: " + memory);
}

