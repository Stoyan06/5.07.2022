﻿// See https://aka.ms/new-console-template for more information

//int priceOfTheShip = 0;
double endPrice = 0;

int budjet = int.Parse(Console.ReadLine());
if(budjet < 1 || budjet > 8000)
{
    Console.WriteLine("Invalid budjet! Please type budjet between 1 and 8000!");
}

string season = Console.ReadLine();

int brRibari = int.Parse(Console.ReadLine());
if(brRibari < 4 || brRibari > 18)
{
    Console.WriteLine("Invalid amount of people! The amount of people should be between 4 and 18!");
}


switch (season)
{
    case "Spring":
        {
            endPrice = 3000;

            if(brRibari <= 6)
            {
                endPrice = endPrice * 0.9;
            }


            if (brRibari >= 7 && brRibari <= 11)
            {
                endPrice = endPrice * 0.85;
            }


            if (brRibari >= 12)
            {
                endPrice = endPrice * 0.75;
            }

            if (brRibari % 2 == 0)
            {
                endPrice = endPrice * 0.95;
            }

            if(budjet > endPrice)
            {
                Console.WriteLine("Yes! You have {0:f2} leva left!", Math.Round(budjet - endPrice,2));
            }

            if (budjet < endPrice)
            {
                Console.WriteLine("No! You need {0:f2} leva more!", Math.Round(endPrice - budjet, 2));
            }
            break;
        }


    case "Summer":
        {
            endPrice = 4200;

            if (brRibari <= 6)
            {
                endPrice = endPrice * 0.9;
            }


            if (brRibari >= 7 && brRibari <= 11)
            {
                endPrice = endPrice * 0.85;
            }


            if (brRibari >= 12)
            {
                endPrice = endPrice * 0.75;
            }

            if (brRibari % 2 == 0)
            {
                endPrice = endPrice * 0.95;
            }

            if (budjet > endPrice)
            {
                Console.WriteLine("Yes! You have {0:f2} leva left!", Math.Round(budjet - endPrice, 2));
            }

            if (budjet < endPrice)
            {
                Console.WriteLine("No! You need {0:f2} leva more!", Math.Round(endPrice - budjet, 2));
            }
            break;
        }


    case "Autumn":
        {
            endPrice = 4200;

            if (brRibari <= 6)
            {
                endPrice = endPrice * 0.9;
            }


            if (brRibari >= 7 && brRibari <= 11)
            {
                endPrice = endPrice * 0.85;
            }


            if (brRibari >= 12)
            {
                endPrice = endPrice * 0.75;
            }

            

            if (budjet > endPrice)
            {
                Console.WriteLine("Yes! You have {0:f2} leva left!", Math.Round(budjet - endPrice, 2));
            }

            if (budjet < endPrice)
            {
                Console.WriteLine("No! You need {0:f2} leva more!", Math.Round(endPrice - budjet, 2));
            }
            break;
        }


    case "Winter":
        {
            endPrice = 2600;

            if (brRibari <= 6)
            {
                endPrice = endPrice * 0.9;
            }


            if (brRibari >= 7 && brRibari <= 11)
            {
                endPrice = endPrice * 0.85;
            }


            if (brRibari >= 12)
            {
                endPrice = endPrice * 0.75;
            }

            if (brRibari % 2 == 0)
            {
                endPrice = endPrice * 0.95;
            }

            if (budjet > endPrice)
            {
                Console.WriteLine("Yes! You have {0:f2} leva left!", Math.Round(budjet - endPrice, 2));
            }

            if (budjet < endPrice)
            {
                Console.WriteLine("No! You need {0:f2} leva more!", Math.Round(endPrice - budjet, 2));
            }
            break;
        }
}