﻿int goal = 10000;
int stepsSum = 0;
string steps = Console.ReadLine();
while (steps != "Going home")
{
   int steps2 = int.Parse(steps);

    
    stepsSum = stepsSum + steps2;

    

    if (stepsSum == goal)
    {
        Console.WriteLine("Goal reached!");
    }

    if (stepsSum > goal)
    {
        Console.WriteLine("{0} steps over the goal!", stepsSum - goal);
    }

    steps = Console.ReadLine();

}
int steps3 = int.Parse(Console.ReadLine());
stepsSum = stepsSum + steps3;

if (stepsSum == goal)
{
    Console.WriteLine("Goal reached!");
}

if (stepsSum > goal)
{
    Console.WriteLine("{0} steps over the goal!", stepsSum - goal);
}

if (stepsSum < goal)
{
    Console.WriteLine("{0} steps left to the goal!", goal - stepsSum);
}