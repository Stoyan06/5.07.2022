﻿// See https://aka.ms/new-console-template for more information

string neededBook = Console.ReadLine();
string input = Console.ReadLine();
int br = 0;
bool bookIsFound = false;

while (input != "No More Books")
{
	if (neededBook == input)
	{
		bookIsFound = true;
		break;
	}
	else
	{
		br++;
		input = Console.ReadLine();
	}
	
}

if (bookIsFound == true)
{
	Console.WriteLine("You checked {0} books and found it!", br);
}
else
{
	Console.WriteLine("You checked {0} books, but didnt find it!", br);
}
