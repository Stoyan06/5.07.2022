﻿// See https://aka.ms/new-console-template for more information



string typeFlower = Console.ReadLine();

int flowerAmount = int.Parse(Console.ReadLine());
if(flowerAmount < 10 || flowerAmount > 1000)
{
    Console.WriteLine("Invalid amount! Please type amount between 10 and 1000!");
}

int budjet = int.Parse(Console.ReadLine());
if (budjet < 50 || budjet > 2500)
{
    Console.WriteLine("Invalid budjet! Please type budjet between 50 and 1500!");
}

double finalSum = 0;


switch (typeFlower)
{
    case "Roses":
        {
            finalSum = flowerAmount * 5;
            if(flowerAmount > 80)
            {
                finalSum = finalSum * 0.9;
            }

            if(budjet > finalSum)
            {
                Console.WriteLine("You have a great garden with {0} {1} and {2:f2} leva left.", flowerAmount ,typeFlower, Math.Round(budjet - finalSum, 2));
            }

            if(finalSum > budjet)
            {
                Console.WriteLine("Sorry, you need {0:f2} leva more in order to buy the flowers!", Math.Round(finalSum - budjet, 2));
            }
            break;
        }


    case "Dahlias":
        {
            finalSum = flowerAmount * 3.8;
            if (flowerAmount > 90)
            {
                finalSum = finalSum * 0.85;
            }

            if (budjet > finalSum)
            {
                Console.WriteLine("You have a great garden with {0} {1} and {2:f2} leva left.", flowerAmount, typeFlower, Math.Round(budjet - finalSum, 2));
            }

            if (finalSum > budjet)
            {
                Console.WriteLine("Sorry, you need {0:f2} leva more in order to buy the flowers!", Math.Round(finalSum - budjet, 2));
            }
            break;
        }


    case "Tulips":
        {
            finalSum = flowerAmount * 2.8;
            if (flowerAmount > 80)
            {
                finalSum = finalSum * 0.85;
            }

            if (budjet > finalSum)
            {
                Console.WriteLine("You have a great garden with {0} {1} and {2:f2} leva left.", flowerAmount, typeFlower, Math.Round(budjet - finalSum, 2));
            }

            if (finalSum > budjet)
            {
                Console.WriteLine("Sorry, you need {0:f2} leva more in order to buy the flowers!", Math.Round(finalSum - budjet, 2));
            }
            break;
        }


    case "Narcissus":
        {
            finalSum = flowerAmount * 3;
            if (flowerAmount < 120)
            {
                finalSum = finalSum * 1.15;
            }

            if (budjet > finalSum)
            {
                Console.WriteLine("You have a great garden with {0} {1} and {2:f2} leva left.", flowerAmount, typeFlower, Math.Round(budjet - finalSum, 2));
            }

            if (finalSum > budjet)
            {
                Console.WriteLine("Sorry, you need {0:f2} leva more in order to buy the flowers!", Math.Round(finalSum - budjet, 2));
            }
            break;
        }


    case "Gladiolus":
        {
            finalSum = flowerAmount * 3;
            if (flowerAmount < 80)
            {
                finalSum = finalSum * 1.20;
            }

            if (budjet > finalSum)
            {
                Console.WriteLine("You have a great garden with {0} {1} and {2:f2} leva left.", flowerAmount, typeFlower, Math.Round(budjet - finalSum,2));
            }

            if (finalSum > budjet)
            {
                Console.WriteLine("Sorry, you need {0:f2} leva more in order to buy the flowers!", Math.Round(finalSum - budjet, 2));
            }
            break;
        }

    default:
        Console.WriteLine("Invalid type of flowers!");
        break;

}
