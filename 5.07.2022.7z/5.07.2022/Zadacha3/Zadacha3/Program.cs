﻿int n = int.Parse(Console.ReadLine());
int currentNumber = 1;

for(int i = 1; i <= n; i++)
{
    for(int y = 1; y <= i; y++)
    {
        Console.Write(currentNumber);
        currentNumber++;
        if(currentNumber > n)
        {
            return;
        }
      
    }
    Console.WriteLine();
}

